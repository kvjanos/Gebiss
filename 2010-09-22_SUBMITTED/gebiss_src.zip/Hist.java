public class Hist {
	private int count;
	private float secondValue;
	private float fValue;
	private int fourthValue;
	
	public Hist(int count) {
		super();
		this.count = count;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getSecondValue() {
		return secondValue;
	}
	public void setSecondValue(float secondValue) {
		this.secondValue = secondValue;
	}
	public float getFValue() {
		return fValue;
	}
	public void setFValue(float value) {
		fValue = value;
	}
	public int getFourthValue() {
		return fourthValue;
	}
	public void setFourthValue(int fourthValue) {
		this.fourthValue = fourthValue;
	}

}
